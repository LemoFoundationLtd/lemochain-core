package store

func IsExist(path string) (bool, error) {
	return false, nil
}
